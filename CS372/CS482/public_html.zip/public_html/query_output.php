<!-- Code for form found at:
https://www.w3schools.com/php/showphp.asp?filename=demo_form_validation_escapechar
-->
<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>

<?php
include 'sql_connection.php';

// define variables and set to empty values
$sqlqueryErr = "";
$sqlquery = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["sqlquery"])) {
    $sqlqueryErr = "Query required";
  } else {
    $sqlquery = test_input($_POST["sqlquery"]);
  }
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

$result = mysqli_query($con, $sqlquery);
echo mysqli_fetch_field($result)->orgname;

$con->close();
?>

</body>
</html>
