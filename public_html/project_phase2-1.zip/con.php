<?php
$host="dbclass.cs.nmsu.edu";
$port=3306;
$user="sgrayson";
$password="2AO08oFO";
$dbname="cs482502fa18_sgrayson";

$con = new mysqli($host, $user, $password, $dbname, $port)
	or die ('Could not connect to the database server <br>' . mysqli_connect_error());

if(!$con){ die('Could not connect <br>'); }
?>
