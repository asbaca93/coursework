#ifndef AST_H
#define AST_H

#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

static int mydebug;

/* define the enumerated types for the AST.  THis is used to tell us what 
sort of production rule we came across */

/* this is a partial list of NODE types for the ASTNode */

/*************************************
* Added symboltable.h library
************************************/

enum ASTtype {
   VARDEC,
   IDENT,
   FUNCTDEC,
   BLOCK,
   EXPRSTMT,
   ASSIGN,
   IFSTMT,
   RET,
   READSTMT,
   WRITESTMT,
   EXPR,
   NUMBER,
   CALL,
   ARGLIST,
   PARAM,
   WHILESTMT,
  
   
//.... stuff is missing
}; 


 enum OPERATORS {
   PLUS,
   MINUS,
   TIMES,
   DIVIDE,
   INTTYPE,
   VOIDTYPE,
   LESS,
   GREATER,
   EQUAL,
   NEQUAL,
   GREQUAL,
   LSEQUAL,
   
//..... stuff is missing
}; 

/* define a type AST node which will hold pointers to AST structs that will
   allow us to represent the parsed code 
*/
  typedef struct ASTnodetype
{
     enum ASTtype type;
     enum OPERATORS operator, istype;
     char * name;
     int value;
     struct ASTnodetype *next,*left,*right; /* left is usually the connector for statements */
     struct SymbTab * symbol;
     struct ASTnodetype *s0,*s1,*s2 ; /* used for holding IF and WHILE components -- not very descriptive */
} ASTnode; 

ASTnode *program;
#include "symtable.h"

ASTnode *ASTCreateNode(enum ASTtype mytype);
void ASTattachleft(ASTnode *p,ASTnode *q);
void ASTprint(int level,ASTnode *p);



#endif
