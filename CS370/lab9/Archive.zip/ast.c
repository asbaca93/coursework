/*   Abstract syntax tree code

     This code is used to define an AST node, 
    routine for printing out the AST
    defining an enumerated type so we can figure out what we need to
    do with this.  The ENUM is basically going to be every non-terminal
    and terminal in our language.

    Shaun Cooper February 2015

*/

/*
  Modified By andrew Baca last on 3/26/2018
  Mods:
        addition of a printtab function
        major additions to astprint based on semantics in yacc
*/
#include "ast.h"

static int mydebug;


/* uses malloc to create an ASTnode and passes back the heap address of the newly created node */
ASTnode *ASTCreateNode(enum ASTtype mytype)
{
    ASTnode *p;
    if (mydebug) fprintf(stderr,"Creating AST Node \n");
    p=(ASTnode *)malloc(sizeof(ASTnode));
    p->type=mytype;
    p->next=NULL;               //added nexr for lists
    p->left=NULL; 
    p->right=NULL;
    p->symbol = NULL;
    p->s0=NULL;
    p->s1=NULL;
    p->s2=NULL;
    p->value=0;
    return(p);
}
    



void Ptab(int level){                                       //added functionality to print tabs
        int i;
        for( i = 0; i < level; i++)  printf("   ");
}



/*  Print out the abstract syntax tree */
void ASTprint(int level,ASTnode *p)
{
   int i;
   if (p == NULL ) return;
   else
     { 
       for( i = 0; i < level; i++)  printf("   ");
       switch (p->type) {
        case VARDEC :  printf("VARIABLE ");                 //print variable declarations
                     if (p->operator == INTTYPE)            //with type and possible value
                         printf("INT"); 
                     if (p->operator == VOIDTYPE)
                         printf("VOID");
                     printf(" %s", p->name);
                     if (p->value > 0)
                        printf("[%d]",p->value);
                     printf("\n");
                     break;
        case FUNCTDEC :                                     //print fuction declaration
                     if (p->operator == INTTYPE)
                         printf("INT ");
                     if (p->operator == VOIDTYPE)
                         printf("VOID ");
                     printf("FUNCTION %s \n",p->name);
                     if(p->left == NULL)
                         printf("(VOID Parameters)\n");
                     else{
                         printf("(\n");
                        ASTprint(level + 1, p->left);         //chack and print parameters within
                        Ptab(level);                          //function declaration
                        printf(")\n");
                     }
                     ASTprint(level + 1, p->right);             //print block
                     break;
        case PARAM : printf("PARAMETER ");                      //print parameters with type
                    if (p->operator == INTTYPE)                 //and possible value
                         printf("INT "); 
                    if (p->operator == VOIDTYPE)
                         printf("VOID ");
                    printf(" %s", p->name);
                    if(p->value > 0)
                        printf("[%d]", p->value);
                    printf("\n");
                    break;
        case BLOCK : printf("BLOCK SATATEMENT\n");              //print block within function
                    Ptab(level);
                    printf("{\n");
                    ASTprint(level + 1, p->left);               //print local declarations
                    ASTprint(level + 1, p->right);              //print statementlist
                    Ptab(level);
                    printf("}\n");
                    break;
        case EXPRSTMT: printf("EXPRESSION STATEMENT \n");
                    ASTprint(level + 1, p->right);              //print exprstmt
                    break;
        case ASSIGN : printf("ASSIGNMENT STATEMENT \n");
                    ASTprint(level+1, p->s1);                   //print assignment statement 
                    ASTprint(level+1, p->right);                //with value
                    break;
        case IFSTMT : printf("IF STATEMENT \n");
                    Ptab(level);
                    printf("( \n");
                    ASTprint(level+1, p->right);                //print if and possible else
                    Ptab(level);
                    printf(")\n");
                    ASTprint(level+2, p->s1);
                    if(p->s2 != NULL){
                        Ptab(level);
                        printf("ELSE \n");
                        ASTprint(level + 3, p->s2);
                    }
                    break;
        case WHILESTMT : printf("WHILE STATEMENT \n");
                    Ptab(level);
                    printf("(\n");
                    ASTprint(level+1, p->right);                //print while
                    Ptab(level);
                    printf(")\n");
                    ASTprint(level+2, p->s1);
                    break;
        case EXPR : printf("EXPR ");

                    if(p->operator == PLUS)                     //conditions for operatios
                        printf(" + ");
                    if(p->operator == MINUS)
                        printf(" - ");
                    if(p->operator == TIMES)
                        printf(" * ");
                    if(p->operator == DIVIDE)
                        printf(" / ");
                    if(p->operator == EQUAL)
                        printf(" == ");
                    if(p->operator == LESS)
                        printf(" < ");
                    if(p->operator == GREATER)
                        printf(" > ");
                    if(p->operator == NEQUAL)
                        printf(" != ");
                    if(p->operator == GREQUAL)
                        printf(" >= ");
                    if(p->operator == LSEQUAL)
                        printf(" <= ");
                    printf("\n");
                    ASTprint(level+1, p->left);                 //print sides of expression
                    ASTprint(level+1,p->right);
                    break;
        case RET : printf("RETURN \n");                         //print return with possible value
                    if(p->right != NULL){
                        Ptab(level);        
                        printf("(\n");
                        ASTprint(level+1, p->right);
                        Ptab(level);
                        printf(")\n");
                    }
                    break;
        case READSTMT : printf("READ STATEMENT \n");            //print read statement
                    ASTprint(level+1, p->right);
                    break;
        case WRITESTMT : printf("WRITE STATEMENT \n");          //print write statement
                    ASTprint(level+1, p->right);
                    break;
        case IDENT : printf("IDENTIFIER ");                     //print identifier with                     
                    printf("%s \n", p->name);
                    if(p->right != NULL){                       //name and num
                        Ptab(level);
                        printf("Array reference [\n");
                        ASTprint(level+2, p->right);
                        Ptab(level);
                        printf("] end array\n");
                    }
                    break;
        case NUMBER : printf("NUMBER ");                        //print number
                    printf("%d \n", p->value);
                    break;
        case CALL : printf("CALL %s\n", p->name);
                    Ptab(level);        
                    printf("(\n");                              //print call
                    ASTprint(level+1,p->right);
                    Ptab(level);
                    printf(")\n");
                    break;
        case ARGLIST : printf("ARGLIST \n");                    //print argument list
                    ASTprint(level+1, p->s1);
                    break;
               
//....missing
        default: printf("unknown type in ASTprint\n");              

       }
     }
    ASTprint(level, p->next);                                   //print next node
}


//Deleted main
