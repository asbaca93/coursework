#ifndef EMIT_H
#define EMIT_H


#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include "ast.h"

void printReturn(FILE *out, ASTnode *p);			//prints the return statement to output file, along with companion value
void ASTemit(ASTnode *p, FILE *out);				//function called by main in YACC to emit assembly to file
void ASTemitCommon(ASTnode *p, FILE *out);			//takes care of veriable declarations
void ASTemitText(ASTnode *p, FILE *out);			//prints the main body of the assembly code
void ASTemitStrings(ASTnode *p, FILE *out);			//prints the strings with labels in the header of assembly
void emitIdentifier(ASTnode *p, FILE *out);			//postcondition: rax is the address of the identifier
void emitExpression(ASTnode *p, FILE *out);			//postcondition: result of the expression will be stored in the offset allocated for this expression 
void emitFunction(ASTnode *p, FILE *out);			//postcondition: function is performed, result will be stored if offset allocated if there is a return
void evaluateArgs(ASTnode *p, FILE *out);			//evaluates the arguments of a function and stores them in offsets
void argsToParams(ASTnode *p, ASTnode *args, ASTnode *fparms, FILE *out);
			



#endif
